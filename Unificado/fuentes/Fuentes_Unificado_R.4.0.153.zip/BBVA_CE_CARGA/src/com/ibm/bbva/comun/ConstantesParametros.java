package com.ibm.bbva.comun;

public interface ConstantesParametros {

	/** Par�metros - ACTUALIZACION_FERIADOS_CARGA **/

	String FERIADOS_FRECUENCIA_DIAS = "feriados.frecuenciaDias";

	String FERIADOS_HORA_EJECUCION = "feriados.horaEjecucion";
	
	String FERIADOS_FLAG_CARGA_ACTIVO = "feriados.cargaActivo";
	
//	String OFICINAS_FRECUENCIA_DIAS = "oficinas.frecuenciaDias";
//
//	String OFICINAS_HORA_EJECUCION = "oficinas.horaEjecucion";
//	
//	String OFICINAS_FLAG_CARGA_ACTIVO = "oficinas.cargaActivo";
	
}
