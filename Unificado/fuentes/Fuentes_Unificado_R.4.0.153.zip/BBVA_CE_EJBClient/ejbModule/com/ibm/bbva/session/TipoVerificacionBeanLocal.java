package com.ibm.bbva.session;

import java.util.List;

import com.ibm.bbva.entities.TipoVerificacion;

public interface TipoVerificacionBeanLocal {

	public List<TipoVerificacion> buscarTodos();
}
