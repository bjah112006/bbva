package com.ibm.bbva.session;

import com.ibm.bbva.entities.PautaClasificacion;

public interface PautaClasificacionBeanLocal {
	public PautaClasificacion buscarPorIdPersona(long idPersona);
}
