package com.ibm.bbva.session;

import com.ibm.bbva.entities.CarterizacionCE;

public interface CarterizacionCEBeanLocal {	
	//Emitson
	public CarterizacionCE buscarPorIdProdIdTerrIdPerfil(String codigo);

}
