package com.ibm.bbva.session;

import java.util.List;

import com.ibm.bbva.entities.LineaMaxima;

public interface LineaMaximaBeanLocal {
	public List<LineaMaxima> buscarTodos();
}
