package com.ibm.bbva.vo;

public class EmpleadoBancoVO extends ObjetoServicioVO {

	private String codigo;
	private String usuario;
	private String nombres;
	private String apePaterno;
	private String apeMaterno;
	private CargoBancoVO cargo;
	private OficinaBancoVO oficina;
	private String correo;
	private String telefono;
	
	public String getCodigo() {
		return codigo;
	}
	
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	public String getNombres() {
		return nombres;
	}
	
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}
	
	public String getApePaterno() {
		return apePaterno;
	}
	
	public void setApePaterno(String apePaterno) {
		this.apePaterno = apePaterno;
	}
	
	public String getApeMaterno() {
		return apeMaterno;
	}
	
	public void setApeMaterno(String apeMaterno) {
		this.apeMaterno = apeMaterno;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public CargoBancoVO getCargo() {
		return cargo;
	}

	public void setCargo(CargoBancoVO cargo) {
		this.cargo = cargo;
	}

	public OficinaBancoVO getOficina() {
		return oficina;
	}

	public void setOficina(OficinaBancoVO oficina) {
		this.oficina = oficina;
	}

}
