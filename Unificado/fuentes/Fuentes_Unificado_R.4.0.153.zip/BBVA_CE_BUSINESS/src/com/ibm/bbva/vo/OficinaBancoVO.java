package com.ibm.bbva.vo;

public class OficinaBancoVO {

	private String codigo;
	private String descripcion;
	private String teleOfi1;
	private String teleOfi2;
	
	public String getCodigo() {
		return codigo;
	}
	
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getTeleOfi1() {
		return teleOfi1;
	}

	public void setTeleOfi1(String teleOfi1) {
		this.teleOfi1 = teleOfi1;
	}

	public String getTeleOfi2() {
		return teleOfi2;
	}

	public void setTeleOfi2(String teleOfi2) {
		this.teleOfi2 = teleOfi2;
	}

}
