package com.ibm.bbva.vo;

public class ObjetoServicioVO {

	private int codigoResultado;

	public int getCodigoResultado() {
		return codigoResultado;
	}

	public void setCodigoResultado(int codigoResultado) {
		this.codigoResultado = codigoResultado;
	}
}
