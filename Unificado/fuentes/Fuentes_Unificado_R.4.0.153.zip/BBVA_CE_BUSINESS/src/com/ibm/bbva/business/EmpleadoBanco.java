package com.ibm.bbva.business;

import java.net.URL;

import com.grupobbva.bc.per.tele.ldap.serializable.IILDPeCargo;
import com.grupobbva.bc.per.tele.ldap.serializable.IILDPeOficina;
import com.grupobbva.bc.per.tele.ldap.serializable.IILDPeUsuario;
import com.grupobbva.bc.per.tele.ldap.session.SesionLdapPeru;
import com.grupobbva.bc.per.tele.ldap.session.SesionLdapPeruServiceLocator;
import com.ibm.bbva.service.Constantes;
import com.ibm.bbva.vo.CargoBancoVO;
import com.ibm.bbva.vo.EmpleadoBancoVO;
import com.ibm.bbva.vo.OficinaBancoVO;

public class EmpleadoBanco {

	public EmpleadoBancoVO buscarUsuario (String nombreUsuario) {
		EmpleadoBancoVO empleadoBancoVO = new EmpleadoBancoVO ();
		OficinaBancoVO oficinaBancoVO = new OficinaBancoVO ();
		
		try {
			SesionLdapPeruServiceLocator serviceLocator = new SesionLdapPeruServiceLocator();
			SesionLdapPeru port = serviceLocator.getSesionLdapPeru(new URL("http://118.190.20.71:9080/ldap2WS/services/SesionLdapPeru"));
			IILDPeUsuario usuario = port.recuperarUsuario(nombreUsuario);
		
			if (usuario == null) {
				empleadoBancoVO.setCodigoResultado(Constantes.CODIGO_NO_UBICADO);
			} else {				
				copiarEmpleado(empleadoBancoVO, usuario);
				empleadoBancoVO.setUsuario(nombreUsuario);
				empleadoBancoVO.setCodigoResultado(Constantes.CODIGO_UBICADO);
				empleadoBancoVO.setCodigo(usuario.getBancoOficina().getCodigo());
				empleadoBancoVO.setOficina(oficinaBancoVO);
			}
		} catch (Exception e) {
			empleadoBancoVO.setCodigoResultado(Constantes.CODIGO_ERROR_CONEXION);
		}
		
		return empleadoBancoVO;
	}
	
	private CargoBancoVO crearCargo (IILDPeCargo cargo) {
		CargoBancoVO vo = new CargoBancoVO ();
		vo.setCodigo(cargo.getCodigo());
		vo.setDescripcion(cargo.getDescripcion());
		return vo;
	}
	
	private OficinaBancoVO crearOficina (IILDPeOficina oficina) {
		OficinaBancoVO vo = new OficinaBancoVO ();
		vo.setCodigo(oficina.getCodigo());
		vo.setDescripcion(oficina.getDescripcion());
		vo.setTeleOfi1(oficina.getTeleOfi1());
		vo.setTeleOfi2(oficina.getTeleOfi2());
		return vo;
	}
	
	private void copiarEmpleado (EmpleadoBancoVO vo, IILDPeUsuario usuario) {
		vo.setApeMaterno(usuario.getApellido2());
		vo.setApePaterno(usuario.getApellido1());
		vo.setCodigo(usuario.getCodGer());
		vo.setNombres(usuario.getNombre());
		vo.setCorreo(usuario.getEmail());
		vo.setTelefono(usuario.getTelefono());
		vo.setCargo(crearCargo(usuario.getCargo()));
		vo.setOficina(crearOficina(usuario.getBancoOficina()));
	}
}