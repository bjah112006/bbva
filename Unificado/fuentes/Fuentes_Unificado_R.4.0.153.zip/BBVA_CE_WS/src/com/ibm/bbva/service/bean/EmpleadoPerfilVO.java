package com.ibm.bbva.service.bean;

public class EmpleadoPerfilVO {

	private EmpleadoVO empleadoVO;
	private String descripcionPerfil;
	
	public EmpleadoVO getEmpleadoVO() {
		return empleadoVO;
	}
	public void setEmpleadoVO(EmpleadoVO empleadoVO) {
		this.empleadoVO = empleadoVO;
	}
	public String getDescripcionPerfil() {
		return descripcionPerfil;
	}
	public void setDescripcionPerfil(String descripcionPerfil) {
		this.descripcionPerfil = descripcionPerfil;
	}
	
	
}
