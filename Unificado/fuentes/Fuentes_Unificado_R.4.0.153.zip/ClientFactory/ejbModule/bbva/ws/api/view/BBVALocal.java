package bbva.ws.api.view;

public interface BBVALocal {

}
