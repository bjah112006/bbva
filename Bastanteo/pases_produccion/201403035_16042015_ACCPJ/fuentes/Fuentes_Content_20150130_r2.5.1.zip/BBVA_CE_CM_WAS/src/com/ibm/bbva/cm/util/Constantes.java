package com.ibm.bbva.cm.util;

public class Constantes {

	public static final String WS_PATH_PROPERTY_NAME = "ws.path";
	public static final String WS_PATH_PROPERTY_NAME_CC = "ws.path_cc";
	public static final String FTP_HOST = "ftp.host";
	public static final String FTP_USER = "ftp.user";
	public static final String FTP_PASS = "ftp.pass";
	public static final String DATE_FORMAT = "date.format";
	public static final String CODIGO_DOC_CM = "30";
	public static final String ORIGEN_ARCHIVO_CC = "PCC";
	public static final String ORIGEN_ARCHIVO_TC = "PTC";
	public static final String RUTA_CONVERSION = "rutaConversion";
	
}
