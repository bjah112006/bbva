package com.ibm.bbva.cm.service.impl;

public class BaseServiceImpl {
	
}
